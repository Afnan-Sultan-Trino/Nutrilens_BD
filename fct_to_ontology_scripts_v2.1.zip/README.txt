Reproduce Food_Nutritional_Knowledge_Graph_v2.ttl from the INFS FCT 2013 PDF:
  python3 parse_fct.py FCT_10_2_14_final_version.pdf      -> fct_parsed.json  (all 381 foods, main tables)
  python3 parse_annex4.py FCT_10_2_14_final_version.pdf   -> annex4.json      (phytate / oxalate)
  python3 build_ttl.py fct_parsed.json annex4.json Food_Nutritional_Knowledge_Graph_v2.ttl
  python3 check_ttl.py Food_Nutritional_Knowledge_Graph_v2.ttl                (syntax + consistency check)
Needs: pdfplumber. To add a food: add one line to the list F in build_ttl.py (individual, class, FCT code, ...).

v2.1: build_ttl.py now also writes the constraint axioms (disjoint classes, functional data properties,
value ranges, hasKey, AllDifferent). check_owl.py checks exactly those constraint types:
  python3 check_owl.py Food_Nutritional_Knowledge_Graph_v2.1.ttl   (exit 0 = consistent)
It is not a full OWL reasoner; confirm with HermiT in Protégé.
