# Turtle parser (subset incl. blank nodes and lists) + emulation of the OWL 2 constraints used in v2.1:
#   disjoint classes (with subclass + domain/range type inference), functional data properties,
#   datatype facets (minInclusive / minExclusive on xsd:float), owl:hasKey + owl:AllDifferent.
# It is NOT a full OWL reasoner; it checks exactly the constraint types this ontology declares.
# Usage: python3 check_owl.py file.ttl   -> exit code 0 = consistent, 1 = inconsistent
import re, sys
from collections import defaultdict
src = open(sys.argv[1], encoding='utf-8').read()

TOK = re.compile(r'''
 (?P<ws>\s+|\#[^\n]*)
|(?P<tlit>"""(?:.|\n)*?""")
|(?P<lit>"(?:[^"\\\n]|\\.)*")
|(?P<iri><[^>\s]*>)
|(?P<dt>\^\^)
|(?P<lang>@[a-zA-Z]+(?:-[a-zA-Z0-9]+)*)
|(?P<kw>@prefix|@base)
|(?P<pname>[A-Za-z_][\w\-]*:[\w\-]*|:[\w\-]+|:)
|(?P<a>a(?=\s))
|(?P<punct>[;,.()\[\]])
''', re.X)
toks = []; i = 0
while i < len(src):
    m = TOK.match(src, i)
    if not m: sys.exit(f'LEX ERROR at char {i}: {src[i:i+60]!r}')
    i = m.end()
    if m.lastgroup != 'ws': toks.append((m.lastgroup, m.group()))

prefixes = {}; T = []; pos = 0; bn = [0]
def peek(): return toks[pos] if pos < len(toks) else (None, None)
def nxt():
    global pos; t = toks[pos]; pos += 1; return t
def expect(v):
    t = nxt()
    if t[1] != v: sys.exit(f'PARSE ERROR: expected {v!r}, got {t} near {toks[pos-6:pos+2]}')
def new_bnode():
    bn[0] += 1; return f'_:b{bn[0]}'
def pred_obj_list(s, end):
    while True:
        p = term()
        while True:
            T.append((s, p, term()))
            if peek()[1] == ',': nxt(); continue
            break
        if peek()[1] == ';':
            nxt()
            if peek()[1] in ('.', ']') : break
            continue
        break
def term():
    k, v = nxt()
    if k == 'iri': return v
    if k == 'a': return 'rdf:type'
    if k == 'pname':
        if v.split(':')[0] not in prefixes: sys.exit(f'UNDECLARED PREFIX in {v}')
        return v
    if k in ('lit', 'tlit'):
        if peek()[0] == 'dt': nxt(); return ('lit', v, nxt()[1])
        if peek()[0] == 'lang': return ('lit', v, nxt()[1])
        return ('lit', v, None)
    if v == '(':
        items = []
        while peek()[1] != ')': items.append(term())
        nxt(); return ('list', tuple(items))
    if v == '[':
        b = new_bnode()
        if peek()[1] != ']': pred_obj_list(b, ']')
        expect(']'); return b
    sys.exit(f'PARSE ERROR: unexpected {k} {v!r} near {toks[pos-6:pos+2]}')
while pos < len(toks):
    if peek()[1] == '@prefix':
        nxt(); p = nxt()[1]; iri = nxt()[1]; expect('.'); prefixes[p.rstrip(':')] = iri; continue
    if peek()[1] == '@base':
        nxt(); nxt(); expect('.'); continue
    s = term()
    if peek()[1] != '.': pred_obj_list(s, '.')
    expect('.')

# ---------------- index
SP = defaultdict(lambda: defaultdict(list))
for s, p, o in T: SP[s][p].append(o)
def objs(s, p): return SP[s].get(p, [])
def typed(t): return {s for s in SP if t in objs(s, 'rdf:type')}
classes = typed('owl:Class'); objp = typed('owl:ObjectProperty'); datap = typed('owl:DatatypeProperty')
inds = typed('owl:NamedIndividual'); functional = typed('owl:FunctionalProperty')
print(f'PARSE OK: {len(T)} statements | classes={len(classes)} objectProps={len(objp)} dataProps={len(datap)} individuals={len(inds)}')

superc = {c: {o for o in objs(c, 'rdfs:subClassOf') if isinstance(o, str)} for c in classes}
def ancestors(c):
    out, stack = set(), [c]
    while stack:
        x = stack.pop()
        for y in superc.get(x, ()):
            if y not in out: out.add(y); stack.append(y)
    return out
# property equivalence/inverse closure for object props
inv = {}
for p in objp:
    for q in objs(p, 'owl:inverseOf'): inv[p] = q; inv[q] = p
eq = defaultdict(set)
for p in objp:
    for q in objs(p, 'owl:equivalentProperty'): eq[p].add(q); eq[q].add(p)
dom = {p: objs(p, 'rdfs:domain') for p in objp | datap}
rng = {p: objs(p, 'rdfs:range') for p in objp | datap}

types = defaultdict(set)
for s in SP:
    for t in objs(s, 'rdf:type'):
        if isinstance(t, str) and t in classes: types[s].add(t)
def add_assert(s, p, o):
    for d in dom.get(p, []):
        if isinstance(d, str): types[s].add(d)
    if isinstance(o, str):
        for r in rng.get(p, []):
            if isinstance(r, str) and r in classes: types[o].add(r)
for s in list(SP):
    if s not in inds: continue
    for p, os_ in list(SP[s].items()):
        for o in os_:
            if p in objp:
                add_assert(s, p, o)
                for q in eq[p]: add_assert(s, q, o)
                if p in inv: add_assert(o, inv[p], s)
                for q in eq[p]:
                    if q in inv: add_assert(o, inv[q], s)
            elif p in datap:
                add_assert(s, p, o)
for s in list(types): types[s] |= {a for t in list(types[s]) for a in ancestors(t)}

problems = []
# 1) disjointness
groups = []
for s in SP:
    if 'owl:AllDisjointClasses' in objs(s, 'rdf:type'):
        groups.append(objs(s, 'owl:members')[0][1])
for c in classes:
    for d in objs(c, 'owl:disjointWith'): groups.append((c, d))
for g in groups:
    for ind, ts in types.items():
        hit = [c for c in g if c in ts]
        if len(hit) > 1: problems.append(f'DISJOINT CLASS VIOLATION: {ind} is inferred to be in {hit}')
# 2) functional data properties
for s in inds:
    for p in functional & datap:
        vals = {o[1] for o in objs(s, p)}
        if len(vals) > 1: problems.append(f'FUNCTIONAL PROPERTY VIOLATION: {s} has {len(vals)} values for {p}: {sorted(vals)}')
# 3) datatype facets
for p in datap:
    for r in rng[p]:
        if isinstance(r, str) and r.startswith('_:'):
            facets = objs(r, 'owl:withRestrictions')[0][1]
            for fb in facets:
                for fk, fv in SP[fb].items():
                    lim = float(fv[0][1].strip('"'))
                    for s in inds:
                        for o in objs(s, p):
                            v = float(o[1].strip('"'))
                            if (fk == 'xsd:minInclusive' and v < lim) or (fk == 'xsd:minExclusive' and v <= lim):
                                problems.append(f'DATATYPE RANGE VIOLATION: {s} {p} = {v} (range requires {fk} {lim})')
# 4) hasKey + AllDifferent
alldiff = set()
for s in SP:
    if 'owl:AllDifferent' in objs(s, 'rdf:type'): alldiff |= set(objs(s, 'owl:distinctMembers')[0][1])
for c in classes:
    for keylist in objs(c, 'owl:hasKey'):
        keyp = keylist[1]
        seen = defaultdict(list)
        for s in inds:
            if c in types[s]:
                k = tuple(tuple(sorted(o[1] for o in objs(s, p))) for p in keyp)
                if all(k): seen[k].append(s)
        for k, ss in seen.items():
            if len(ss) > 1:
                msg = f'HASKEY: {ss} share key {k} -> inferred owl:sameAs'
                if all(x in alldiff for x in ss): problems.append(msg + ', but they are declared owl:AllDifferent')
                else: problems.append(msg + ' (identity merge)')
missing_alldiff = [i for i in inds if i not in alldiff]
if alldiff and missing_alldiff: print('note: individuals not in AllDifferent:', missing_alldiff)

if problems:
    print('RESULT: INCONSISTENT'); print(*('  ' + p for p in problems), sep='\n'); sys.exit(1)
print('RESULT: CONSISTENT (no violation of the declared disjointness, functional, datatype-range or key axioms)')
