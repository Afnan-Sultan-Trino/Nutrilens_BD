# Builds Food_Nutritional_Knowledge_Graph v2 from parsed INFS FCT 2013 data.
# Usage: python3 -I build_ttl.py fct_parsed.json annex4.json out.ttl
import json, sys, re

fct = json.load(open(sys.argv[1]))['data']
annex = json.load(open(sys.argv[2]))
OUT = sys.argv[3]

# ---------------------------------------------------------------------------
# Reference values: ICMR-NIN 2020 (EAR + RDA), adult man 65 kg / woman 55 kg.
# Carbohydrate is the single exception (not in ICMR-NIN 2020 brief note) -> IOM.
# ---------------------------------------------------------------------------
REF = {
  # name: (class, EAR_m, EAR_f, RDA_m, RDA_f, unit, source)
  'Protein':     ('Macronutrient', 42.9, 36.3, 54.0, 45.7, 'g/day', 'ICMR-NIN 2020 (0.66 g/kg EAR, 0.83 g/kg RDA; ref. body weight 65 kg man / 55 kg woman)'),
  'Carbohydrate':('Macronutrient', 100.0, 100.0, 130.0, 130.0, 'g/day', 'IOM/NASEM DRI — EXCEPTION: not given in the ICMR-NIN 2020 brief note; verify against the ICMR-NIN 2020 full report'),
  'Calcium':     ('Micronutrient', 800.0, 800.0, 1000.0, 1000.0, 'mg/day', 'ICMR-NIN 2020'),
  'Iron':        ('Micronutrient', 11.0, 15.0, 19.0, 29.0, 'mg/day', 'ICMR-NIN 2020 (requirement already assumes the low iron bioavailability of South Asian, cereal-based diets)'),
  'Zinc':        ('Micronutrient', 14.0, 11.0, 17.0, 13.0, 'mg/day', 'ICMR-NIN 2020 (requirement already assumes a phytate-rich diet)'),
  'VitaminA':    ('Micronutrient', 460.0, 390.0, 1000.0, 840.0, 'mcg/day', 'ICMR-NIN 2020 (expressed as retinol; FCT food values are RAE — check the carotene conversion factor before comparing)'),
  'VitaminC':    ('Micronutrient', 65.0, 55.0, 80.0, 65.0, 'mg/day', 'ICMR-NIN 2020'),
  'VitaminD':    ('Micronutrient', 10.0, 10.0, 15.0, 15.0, 'mcg/day', 'ICMR-NIN 2020 (400 IU EAR / 600 IU RDA); diet is a minor vitamin D source compared with sunlight'),
  'Folate':      ('Micronutrient', 250.0, 180.0, 300.0, 220.0, 'mcg/day', 'ICMR-NIN 2020 (DFE); FCT folate is total food folate'),
}
# thresholds for auto-derived links (per serving, vs adult-woman RDA)
SOURCE_PCT, GOOD_PCT = 10.0, 15.0   # 15% mirrors the Codex "source of" convention

# FCT column -> (data property, nutrient individual or None, unit label)
COLS = [
  ('ENERC_KCAL','hasEnergy_kcal_per_100g', None),
  ('PROT','hasProteinContent_g_per_100g','Protein'),
  ('FAT','hasFatContent_g_per_100g','Fat'),
  ('CHOAVLDF','hasCarbohydrate_g_per_100g','Carbohydrate'),
  ('FIB','hasDietaryFibre_g_per_100g', None),
  ('CA','hasCalcium_mg_per_100g','Calcium'),
  ('FE','hasIronContent_mg_per_100g','Iron'),
  ('ZN','hasZincContent_mg_per_100g','Zinc'),
  ('VITA_RAE','hasVitaminA_mcg_per_100g','VitaminA'),
  ('ASCL','hasVitaminC_mg_per_100g','VitaminC'),
  ('VITD','hasVitaminD_mcg_per_100g','VitaminD'),
  ('FOL','hasFolate_mcg_per_100g','Folate'),
]

# ---------------------------------------------------------------------------
# Foods: (individual, class, FCT code, FCT English name, en label, bn label,
#         serving g, natural unit or None, original?)
# ---------------------------------------------------------------------------
F = [
 # Grain
 ('Bhat','Grain','01_0037','Rice, BR-28, boiled* (without salt)','Rice, boiled (BR-28, parboiled)','ভাত',150,None,True),
 ('Atta','Grain','01_0031','Wheat, flour, white','Wheat flour (atta)','আটা',70,None,True),
 ('Ruti','Grain','01_0042','Ruti*','Ruti (hand-made flatbread)','রুটি',45,'টি (রুটি)',False),
 ('Chira','Grain','01_0010','Rice flaked','Flattened rice (chira)','চিড়া',50,None,False),
 ('Pawruti','Grain','01_0003','Bread, white, for toasting','White bread','পাউরুটি',25,'স্লাইস (পাউরুটি)',False),
 # Mixed dishes
 ('Khichuri','MixedDish','01_0035','Plain Khichuri*','Khichuri (rice-lentil)','খিচুড়ি',250,None,False),
 ('Pulao','MixedDish','01_0036','Plain pulao*','Plain pulao','পোলাও',200,None,False),
 ('AluBhorta','MixedDish','05_0021','Potato Mash*','Mashed potato (alu bhorta)','আলু ভর্তা',75,None,False),
 ('Payesh','MixedDish','12_0013','Payesh*','Payesh (rice pudding)','পায়েস',150,None,False),
 # Legume (also nuts/seeds)
 ('MasoorDal','Legume','02_0015','Lentils, boiled* (without salt)','Red lentil (masoor), boiled','মসুর ডাল',100,None,True),
 ('Chola','Legume','02_0012','Bengal gram, whole, boiled* (without salt)','Chickpea (chola), boiled','ছোলা',100,None,True),
 ('MugDal','Legume','02_0013','Green gram, split, boiled* (without salt)','Mung dal, boiled','মুগ ডাল',100,None,False),
 ('KhesariDal','Legume','02_0014','Grass pea, split, boiled* (without salt)','Khesari dal, boiled','খেসারি ডাল',100,None,False),
 ('Motor','Legume','02_0016','Pea, boiled* (without salt)','Dried pea (motor), boiled','মটর',100,None,False),
 ('ChinaBadam','Legume','06_0007','Groundnuts/Peanut, raw','Peanut','চিনাবাদাম',30,None,False),
 # Green leafy
 ('LalShak','GreenLeafy','04_0032','Amaranth leaves, red, boiled* (without salt)','Red amaranth leaves, boiled','লাল শাক',100,'বাটি (লাল শাক)',True),
 ('PalongShak','GreenLeafy','04_0035','Spinach, boiled* (without salt)','Spinach, boiled','পালং শাক',100,None,True),
 ('DataShak','GreenLeafy','04_0033','Amaranth leaves, green, boiled* (without salt)','Green amaranth leaves, boiled','ডাটা শাক',100,None,False),
 ('PuiShak','GreenLeafy','04_0036','Indian spinach, boiled* (without salt)','Indian spinach (pui), boiled','পুঁই শাক',100,None,False),
 ('KolmiShak','GreenLeafy','04_0030','Water spinach, raw','Water spinach (kolmi), raw value','কলমি শাক',100,None,False),
 ('PatShak','GreenLeafy','04_0021','Jute leaves, raw','Jute leaves (pat shak), raw value','পাট শাক',75,None,False),
 ('KochuShak','GreenLeafy','04_0014','Colocasia leaves, green, raw','Colocasia leaves (kochu shak), raw value','কচু শাক',75,None,False),
 # Other vegetables
 ('Gajar','OtherVegetable','03_0035','Carrot, boiled* (without salt)','Carrot, boiled','গাজর',80,None,True),
 ('MishtiKumra','OtherVegetable','03_0043','Pumpkin, boiled* (without salt)','Pumpkin, boiled','মিষ্টি কুমড়া',100,None,True),
 ('Begun','OtherVegetable','03_0033','Brinjal, purple, long, boiled* (without salt)','Eggplant, boiled','বেগুন',100,None,True),
 ('Alu','OtherVegetable','05_0012','Potato, Diamond, boiled* (without salt)','Potato, boiled','আলু',100,None,True),
 ('MishtiAlu','OtherVegetable','05_0016','Sweet potato, Komola Sundori, orange flesh, boiled* (without salt)','Orange-flesh sweet potato, boiled','মিষ্টি আলু (কমলা শাঁস)',100,None,False),
 ('Fulkopi','OtherVegetable','03_0036','Cauliflower, boiled* (without salt)','Cauliflower, boiled','ফুলকপি',75,None,False),
 ('Badhakopi','OtherVegetable','03_0034','Cabbage, boiled* (without salt)','Cabbage, boiled','বাঁধাকপি',75,None,False),
 ('Dherosh','OtherVegetable','03_0040','Okra/ladies finger, boiled* (without salt)','Okra, boiled','ঢেঁড়স',75,None,False),
 ('Korola','OtherVegetable','03_0047','Gourd, bitter, boiled* (without salt)','Bitter gourd, boiled','করলা',50,None,False),
 ('Potol','OtherVegetable','03_0038','Gourd, pointed, boiled* (without salt)','Pointed gourd, boiled','পটল',75,None,False),
 ('Lau','OtherVegetable','03_0017','Gourd, bottle, raw','Bottle gourd, raw value','লাউ',100,None,False),
 ('Tomato','OtherVegetable','03_0031','Tomato, red, ripe, raw','Tomato','টমেটো',50,None,False),
 ('Shosha','OtherVegetable','03_0012','Cucumber, peeled, raw','Cucumber','শসা',50,None,False),
 ('Peyaj','OtherVegetable','03_0024','Onion, raw','Onion','পেঁয়াজ',20,None,False),
 ('KachaMorich','OtherVegetable','03_0010','Chilli, green, with seeds, raw','Green chilli','কাঁচা মরিচ',5,None,False),
 ('KachaPepe','OtherVegetable','03_0025','Papaya, unripe, raw','Green papaya, raw value','কাঁচা পেঁপে',75,None,False),
 # Citrus
 ('Kamalalebu','CitrusFruit','08_0031','Orange, raw','Orange','কমলা লেবু',130,None,True),
 ('Lebu','CitrusFruit','08_0022','Lemon, Kagoji, raw','Lemon (kagoji)','লেবু',15,None,False),
 # Other fruit
 ('Aam','OtherFruit','08_0026','Mango, Langra, yellow flesh, ripe, raw','Mango (Langra), ripe','আম',150,None,True),
 ('Pepe','OtherFruit','08_0035','Papaya, ripe, raw','Papaya, ripe','পেঁপে',140,None,True),
 ('Amloki','OtherFruit','08_0012','Emblic, raw','Indian gooseberry (amla)','আমলকী',30,None,True),
 ('Kola','OtherFruit','08_0004','Banana, Sagar, ripe, raw','Banana (Sagar), ripe','কলা',100,'টি (কলা)',False),
 ('Peyara','OtherFruit','08_0015','Guava, green, raw','Guava','পেয়ারা',100,None,False),
 ('Kathal','OtherFruit','08_0017','Jackfruit, ripe, raw','Jackfruit, ripe','কাঁঠাল',100,None,False),
 ('Anaros','OtherFruit','08_0038','Pineapple, ripe, raw','Pineapple','আনারস',100,None,False),
 # Meat
 ('MurgirMangsho','Meat','10_0006','Chicken breast, without skin, raw','Chicken breast, raw value','মুরগির মাংস',100,'পিস (মুরগি, ~১০০গ্রাম)',True),
 ('GorurMangsho','Meat','10_0003','Beef, meat, 15-20% fat, boneless, raw','Beef (15–20% fat), raw value','গরুর মাংস',100,None,True),
 ('KhashirMangsho','Meat','10_0011','Goat meat, lean, raw','Goat meat, raw value','খাসির মাংস',75,None,False),
 ('MurgirKoliza','Meat','10_0008','Chicken liver, raw','Chicken liver, raw value','মুরগির কলিজা',50,None,False),
 ('GorurKoliza','Meat','10_0001','Beef liver, raw','Beef liver, raw value','গরুর কলিজা',50,None,False),
 # Fish
 ('Ilish','Fish','09_0033','Hilsha, without bones, raw','Hilsa fish, raw value','ইলিশ মাছ',100,None,True),
 ('Rui','Fish','09_0060','Rohu, without bones, raw','Rohu fish, raw value','রুই মাছ',100,None,True),
 ('Katla','Fish','09_0015','Catla, raw','Catla fish, raw value','কাতলা মাছ',75,None,False),
 ('Pangas','Fish','09_0047','Pangas, without bones, raw','Pangas fish, raw value','পাঙ্গাস মাছ',75,None,False),
 ('Telapia','Fish','09_0068','Tilapia, without bones, raw','Tilapia, raw value','তেলাপিয়া মাছ',75,None,False),
 ('Mola','Fish','09_0043','Mola carplet, whole, eyes included, raw','Mola (small fish, whole), raw value','মলা মাছ',50,None,False),
 ('Kachki','Fish','09_0025','Ganges river sprat, combined species, raw','Kachki (small fish, whole), raw value','কাচকি মাছ',50,None,False),
 ('ChingriGolda','Fish','09_0054','Prawn, Giant river prawn, raw','Giant river prawn (golda), raw value','গলদা চিংড়ি',50,None,False),
 ('KachkiVaji','Fish','09_0071','Small fish fry*','Small fish fry (kachki vaji)','কাচকি মাছ ভাজি',50,None,False),
 # Egg
 ('Dim','Egg','11_0005','Egg, chicken, farmed, boiled* (without salt)','Chicken egg, boiled','ডিম',50,'টি (ডিম)',True),
 ('HasherDim','Egg','11_0007','Egg, duck, whole, boiled* (without salt)','Duck egg, boiled','হাঁসের ডিম',60,'টি (হাঁসের ডিম)',False),
 # Dairy
 ('Dudh','Dairy','12_0008','Milk, cow, whole fat (pasteurized, UTH)','Cow milk, whole','দুধ',240,None,True),
 ('Doi','Dairy','12_0003','Curd, sweetened, whole milk','Sweet curd (mishti doi)','দই',150,None,True),
 # Oil
 ('SoyabeanTel','Oil','13_0012','Soybean oil','Soybean oil','সয়াবিন তেল',10,None,True),
 ('ShorisharTel','Oil','13_0008','Mustard oil','Mustard oil','সরিষার তেল',10,None,False),
 ('Ghee','Oil','13_0004','Ghee, cow','Ghee (cow)','ঘি',10,None,False),
 # Junk
 ('SoftDrink','JunkFood','14_0004','Soft drinks, carbonated','Carbonated soft drink','কোমল পানীয়',250,None,True),
 ('MishtiBiscuit','JunkFood','01_0034','Biscuit, sweet*','Sweet biscuit','মিষ্টি বিস্কুট',25,None,False),
 # Beverage
 ('Cha','Beverage','14_0008','Tea, infusion (with sugar)','Tea with sugar (liquor/red tea)','লিকার চা',200,None,True),
 ('DudhCha','Beverage','14_0007','Tea infusion (with sugar and milk powder, whole fat)','Milk tea (with sugar, milk powder)','দুধ চা',200,None,True),
 ('Coffee','Beverage','14_0002','Coffee infusion (instant with sugar and milk powder, whole fat)','Coffee (with sugar, milk powder)','কফি',200,None,True),
 ('DaberPani','Beverage','14_0001','Coconut water','Coconut water','ডাবের পানি',250,None,False),
 # Sweetener
 ('Chini','Sweetener','15_0008','Sugar, white','White sugar','চিনি',10,None,False),
 ('Gur','Sweetener','15_0004','Jaggery, sugarcane, solid','Jaggery (sugarcane gur)','আখের গুড়',15,None,False),
]

# Kept from v1 but NOT in INFS FCT 2013 -> original values retained and flagged.
NOT_IN_FCT = [
 ('AluChips','JunkFood','Potato chips','আলুর চিপস',30,
  {'hasFatContent_g_per_100g':35.0,'hasCarbohydrate_g_per_100g':53.0,'hasProteinContent_g_per_100g':6.0}),
]

# Absorption inhibitors (curated; evidence noted in comments)
POLYPHENOL_IRON = ['Cha','DudhCha','Coffee']
# phytate-rich cereals/legumes -> raw-ingredient FCT Annex 4 code used as evidence
PHYTATE = {
 'Atta':'01_0031','Ruti':'01_0031','Chira':'01_0010','Pawruti':'01_0032',
 'MasoorDal':'02_0008','Chola':'02_0002','MugDal':'02_0005','KhesariDal':'02_0007','Motor':'02_0009',
 'Khichuri':'02_0008',
}
MEAT_FISH_FACTOR = ['Meat','Fish']
VITC_ENHANCER_MG = 25.0   # per serving

RELIGION = {'GorurMangsho':'Hinduism','GorurKoliza':'Hinduism'}

SYMPTOMS = {
 'Iron':['Fatigue','HairLoss','PoorConcentration','PaleConjunctiva','Koilonychia'],
 'Calcium':['BoneJointPain'],
 'Zinc':['HairLoss','FrequentIllness'],
 'VitaminA':['NightBlindness','DryFlakySkin'],
 'VitaminC':['GumBleeding','FrequentIllness'],
 'VitaminD':['BoneJointPain','DryFlakySkin'],
 'Folate':['Fatigue'],
}

# ---------------------------------------------------------------------------
def parse_val(raw):
    """returns (float or None, flag) flag in {None,'trace','lowq'}"""
    if raw is None: return None, None
    s = raw.strip('()')
    if s.lower() == 'tr': return 0.0, 'trace'
    lowq = s.startswith('[')
    s = s.strip('[]')
    return float(s), ('lowq' if lowq else None)

def lit(x): return f'"{x}"^^xsd:float'
def slit(x): return '"' + x.replace('\\','\\\\').replace('"','\\"') + '"'

lines = []
w = lines.append
w('''@prefix : <http://www.semanticweb.org/as/ontologies/2026/6/Food_Nutrition_Graph/> .
@prefix owl: <http://www.w3.org/2002/07/owl#> .
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix xml: <http://www.w3.org/XML/1998/namespace> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@base <http://www.semanticweb.org/as/ontologies/2026/6/Food_Nutrition_Graph/> .

<http://www.semanticweb.org/as/ontologies/2026/6/Food_Nutrition_Graph> rdf:type owl:Ontology ;
    owl:versionInfo "2.1 (2026-11-21)" ;
    rdfs:comment """Bangladeshi Food Ontology for nutritional-risk estimation and local food recommendation.
VERSION 2.0 CHANGES:
(1) FOOD VALUES: every food except those flagged :notInFCT now takes its per-100 g values from the
    Food Composition Table for Bangladesh (INFS, University of Dhaka, 2013), with the FCT food code in
    :hasFCTCode and the FCT English name in :hasFCTName. Values are per 100 g EDIBLE portion, as eaten
    for boiled*/recipe items and RAW for meat/fish (FCT has no cooked values for most of them).
(2) MISSING IS NOT ZERO: a blank FCT cell is NOT asserted as 0. It is recorded with :hasUnknownValueFor.
    FCT 'Tr' (trace) is stored as 0.0 and marked :hasTraceValueFor. FCT values in [brackets]
    (alternative method / low quality) are stored and marked :hasLowQualityValueFor.
(3) ONE REFERENCE: all nutrient requirements use ICMR-NIN 2020 (EAR and RDA, adult man 65 kg / woman 55 kg),
    except Carbohydrate (IOM; see its comment). Use EAR for risk of inadequate intake (EAR cut-point
    method) and RDA as the target for recommendations.
(4) ABSORPTION: :inhibitsAbsorption added (tea/coffee polyphenols -> iron; phytate-rich cereals/legumes ->
    iron, zinc). ICMR-NIN iron/zinc requirements already assume low-bioavailability diets, so these
    links should be used for EXPLANATION and meal-pairing advice, not to subtract intake a second time.
(5) DERIVED LINKS: :hasNutrient / :isGoodSourceOf are generated by rule (per serving >= 10% / >= 15% of the
    adult-woman RDA). Serving sizes for foods added in v2 are household estimates (see :servingSizeSource).
(6) SYMPTOM INFERENCE: :mayHelpWithSymptom is a property chain (isGoodSourceOf o causesSymptom). It states
    a POSSIBLE dietary link, not a diagnosis.
VERSION 2.1 CHANGES (constraints so that a reasoner consistency check is meaningful):
(7) DISJOINTNESS: Food, Nutrient, Symptom and Religion are pairwise disjoint; the main food groups
    (Grain, Legume, Vegetable, Fruit, Meat, Fish, Egg, Dairy, Oil, Sweetener, JunkFood, Beverage) are pairwise
    disjoint; GreenLeafy/OtherVegetable, CitrusFruit/OtherFruit and Macronutrient/Micronutrient are disjoint.
    MixedDish is deliberately NOT disjoint with the groups (a dish can be decomposed into several groups).
(8) FUNCTIONAL DATA PROPERTIES: every data property is functional, so one food cannot carry two different
    values for the same nutrient, code or serving size.
(9) VALUE RANGES: per-100 g composition values must be >= 0; serving sizes and EAR/RDA values must be > 0
    (OWL 2 datatype restrictions on xsd:float).
(10) IDENTITY: :Food owl:hasKey ( :hasFCTCode ) — two foods with the same FCT code are the same food; and all
    named individuals are declared owl:AllDifferent. Together: a duplicated FCT code makes the ontology
    inconsistent instead of silently merging two foods."""@en .


#################################################################
#    Object Properties
#################################################################

###  causesSymptom
:causesSymptom rdf:type owl:ObjectProperty ;
               rdfs:domain :Nutrient ;
               rdfs:range :Symptom ;
               rdfs:comment "Links a nutrient to a symptom that its deficiency can cause. Symptoms are non-specific (many causes); use as context, not as a label."@en .


###  hasNutrient
:hasNutrient rdf:type owl:ObjectProperty ;
             rdfs:domain :Food ;
             rdfs:range :Nutrient ;
             rdfs:comment "Food is a SOURCE of the nutrient: one serving gives >= 10% of the adult-woman ICMR-NIN 2020 RDA (Fat: >= 5 g per serving). Generated by rule from FCT values."@en .


###  isGoodSourceOf
:isGoodSourceOf rdf:type owl:ObjectProperty ;
                rdfs:subPropertyOf :hasNutrient ;
                rdfs:domain :Food ;
                rdfs:range :Nutrient ;
                rdfs:comment "Food is a GOOD SOURCE of the nutrient: one serving gives >= 15% of the adult-woman ICMR-NIN 2020 RDA (mirrors the Codex 'source of' 15% convention). Generated by rule from FCT values."@en .


###  hasGoodFoodSource
:hasGoodFoodSource rdf:type owl:ObjectProperty ;
                   owl:inverseOf :isGoodSourceOf ;
                   rdfs:domain :Nutrient ;
                   rdfs:range :Food ;
                   rdfs:comment "Inverse of :isGoodSourceOf (Nutrient -> Food). Replaces the v1 property :treatedBy."@en .


###  treatedBy  (kept only for backward compatibility with v1 queries)
:treatedBy rdf:type owl:ObjectProperty ;
           owl:equivalentProperty :hasGoodFoodSource ;
           owl:deprecated "true"^^xsd:boolean ;
           rdfs:comment "DEPRECATED in v2: 'treated by' sounds clinical. Use :hasGoodFoodSource. Kept equivalent so old SPARQL/DL queries still work."@en .


###  enhancesAbsorption
:enhancesAbsorption rdf:type owl:ObjectProperty ;
                    rdfs:domain :Food ;
                    rdfs:range :Nutrient ;
                    rdfs:comment "Eating this food in the SAME MEAL increases absorption of the nutrient (from other foods). v2 rules: vitamin C >= 25 mg per serving -> Iron; meat and fish (the 'meat/fish factor') -> non-haem Iron."@en .


###  inhibitsAbsorption
:inhibitsAbsorption rdf:type owl:ObjectProperty ;
                    rdfs:domain :Food ;
                    rdfs:range :Nutrient ;
                    rdfs:comment "Eating this food in the SAME MEAL reduces absorption of the nutrient (from other foods). v2: tea/coffee polyphenols -> Iron; phytate-rich cereals and legumes -> Iron, Zinc (phytate values: FCT 2013 Annex 4). Because ICMR-NIN requirements already assume a low-bioavailability diet, use for explanation and meal-timing advice (e.g. tea 1 h away from meals), not for a second numeric deduction."@en .


###  mayHelpWithSymptom  (inferred)
:mayHelpWithSymptom rdf:type owl:ObjectProperty ;
                    owl:propertyChainAxiom ( :isGoodSourceOf :causesSymptom ) ;
                    rdfs:domain :Food ;
                    rdfs:range :Symptom ;
                    rdfs:comment "INFERRED by an OWL 2 reasoner (e.g. HermiT in Protégé): Food isGoodSourceOf Nutrient, Nutrient causesSymptom Symptom => Food mayHelpWithSymptom Symptom. Means 'a possible dietary link', never a diagnosis or treatment claim."@en .


###  restrictedByReligion
:restrictedByReligion rdf:type owl:ObjectProperty ;
                      rdfs:domain :Food ;
                      rdfs:range :Religion ;
                      rdfs:comment "Links a food to a religion whose followers commonly avoid it. A simplification: individual practice varies. Prefer asking the person directly; treat as a default, not a rule."@en .


###  hasUnknownValueFor
:hasUnknownValueFor rdf:type owl:ObjectProperty ;
                    rdfs:domain :Food ;
                    rdfs:range :Nutrient ;
                    rdfs:comment "The FCT cell for this nutrient is blank (missing). The nutrient engine must treat it as UNKNOWN (report as missing / reduce confidence), never as zero."@en .


###  hasTraceValueFor
:hasTraceValueFor rdf:type owl:ObjectProperty ;
                  rdfs:domain :Food ;
                  rdfs:range :Nutrient ;
                  rdfs:comment "The FCT reports 'Tr' (trace) for this nutrient; the stored numeric value is 0.0."@en .


###  hasLowQualityValueFor
:hasLowQualityValueFor rdf:type owl:ObjectProperty ;
                       rdfs:domain :Food ;
                       rdfs:range :Nutrient ;
                       rdfs:comment "The FCT value is in [brackets]: alternative analytical method or low quality, to be reconfirmed (FCT 2013, Symbols)."@en .


#################################################################
#    Data properties
#################################################################
''')

dps = [
 ('hasEnergy_kcal_per_100g','Food','xsd:float','FCT ENERC (kcal) per 100 g edible portion.'),
 ('hasProteinContent_g_per_100g','Food','xsd:float','FCT PROT.'),
 ('hasFatContent_g_per_100g','Food','xsd:float','FCT FATCE (fat by Soxhlet).'),
 ('hasCarbohydrate_g_per_100g','Food','xsd:float','FCT CHOAVLDF (available carbohydrate by difference).'),
 ('hasDietaryFibre_g_per_100g','Food','xsd:float','FCT FIBTG or [FIBC].'),
 ('hasCalcium_mg_per_100g','Food','xsd:float','FCT CA.'),
 ('hasIronContent_mg_per_100g','Food','xsd:float','FCT FE.'),
 ('hasZincContent_mg_per_100g','Food','xsd:float','FCT ZN.'),
 ('hasVitaminA_mcg_per_100g','Food','xsd:float','FCT VITA_RAE (retinol activity equivalents).'),
 ('hasVitaminC_mg_per_100g','Food','xsd:float','FCT ASCL.'),
 ('hasVitaminD_mcg_per_100g','Food','xsd:float','FCT VITD.'),
 ('hasFolate_mcg_per_100g','Food','xsd:float','FCT FOL (total food folate).'),
 ('hasPhytate_mg_per_100g','Food','xsd:float','FCT Annex 4 PHYTAC. Only asserted when the food\'s own FCT code is in Annex 4.'),
 ('hasOxalate_mg_per_100g','Food','xsd:float','FCT Annex 4 OXALAC. Only asserted when the food\'s own FCT code is in Annex 4.'),
 ('hasServingSize_g','Food','xsd:float','Weight of one typical serving (or of one natural unit if :hasNaturalUnitLabel is set). Not from FCT; see :servingSizeSource.'),
 ('hasNaturalUnitLabel','Food','xsd:string','Human-friendly countable unit (e.g. \'টি (ডিম)\'); :hasServingSize_g is the weight of ONE such unit.'),
 ('hasFCTCode','Food','xsd:string','INFS Food Composition Table for Bangladesh (2013) food code.'),
 ('hasFCTName','Food','xsd:string','English food name exactly as printed in the FCT. A trailing * means recipe calculation.'),
 ('isRecipeCalculated','Food','xsd:boolean','True when the FCT value is a recipe calculation (* in FCT), not a direct analysis.'),
 ('valueBasis','Food','xsd:string','Physical state the per-100 g values refer to (e.g. boiled, raw).'),
 ('servingSizeSource','Food','xsd:string','Where :hasServingSize_g came from.'),
 ('notInFCT','Food','xsd:boolean','True when the food is not in the INFS FCT 2013 and values come from elsewhere. Replace before publication.'),
 ('hasEAR_male_daily','Nutrient','xsd:float','ICMR-NIN 2020 Estimated Average Requirement, adult man (65 kg). Use for risk of inadequate intake.'),
 ('hasEAR_female_daily','Nutrient','xsd:float','ICMR-NIN 2020 Estimated Average Requirement, adult non-pregnant non-lactating woman (55 kg).'),
 ('hasRDA_male_daily','Nutrient','xsd:float','ICMR-NIN 2020 Recommended Dietary Allowance, adult man. Use as the recommendation target.'),
 ('hasRDA_female_daily','Nutrient','xsd:float','ICMR-NIN 2020 Recommended Dietary Allowance, adult woman.'),
 ('hasRequirementUnit','Nutrient','xsd:string','Unit of the EAR/RDA values.'),
 ('hasReferenceSource','Nutrient','xsd:string','Bibliographic source of the EAR/RDA values.'),
]
def facet(kind):
    return ('[ rdf:type rdfs:Datatype ;\n        owl:onDatatype xsd:float ;\n        owl:withRestrictions ( [ xsd:' + kind + ' "0.0"^^xsd:float ] ) ]')
for name, dom, rng, cmt in dps:
    if name.endswith('_per_100g'): rng_s = facet('minInclusive')
    elif name in ('hasServingSize_g',) or name.startswith('hasEAR_') or name.startswith('hasRDA_'): rng_s = facet('minExclusive')
    else: rng_s = rng
    w(f'''###  {name}
:{name} rdf:type owl:DatatypeProperty , owl:FunctionalProperty ;
    rdfs:domain :{dom} ;
    rdfs:range {rng_s} ;
    rdfs:comment {slit(cmt)}@en .
''')

w('''
#################################################################
#    Classes
#################################################################

:Food rdf:type owl:Class .

:Grain rdf:type owl:Class ; rdfs:subClassOf :Food ;
    rdfs:comment "Cereals and cereal products (FCT group 01)."@en .
:Legume rdf:type owl:Class ; rdfs:subClassOf :Food ;
    rdfs:comment "Pulses (FCT group 02); also covers nuts/seeds (FCT group 06) for simplicity."@en .
:Vegetable rdf:type owl:Class ; rdfs:subClassOf :Food .
:GreenLeafy rdf:type owl:Class ; rdfs:subClassOf :Vegetable ;
    rdfs:comment "Leafy vegetables (FCT group 04)."@en .
:OtherVegetable rdf:type owl:Class ; rdfs:subClassOf :Vegetable ;
    rdfs:comment "Other vegetables (FCT group 03) and starchy roots/tubers (FCT group 05)."@en .
:Fruit rdf:type owl:Class ; rdfs:subClassOf :Food .
:CitrusFruit rdf:type owl:Class ; rdfs:subClassOf :Fruit .
:OtherFruit rdf:type owl:Class ; rdfs:subClassOf :Fruit .
:Meat rdf:type owl:Class ; rdfs:subClassOf :Food ;
    rdfs:comment "Meat, poultry and organ meat (FCT group 10). FCT values are RAW; convert cooked weight before use."@en .
:Fish rdf:type owl:Class ; rdfs:subClassOf :Food ;
    rdfs:comment "Fish and shellfish (FCT group 09). Most FCT values are RAW edible portion; convert cooked weight before use."@en .
:Egg rdf:type owl:Class ; rdfs:subClassOf :Food .
:Dairy rdf:type owl:Class ; rdfs:subClassOf :Food .
:Oil rdf:type owl:Class ; rdfs:subClassOf :Food .
:MixedDish rdf:type owl:Class ; rdfs:subClassOf :Food ;
    rdfs:comment "Multi-ingredient recipe dish with an FCT recipe calculation (*). For WHO dietary-diversity scoring, decompose into ingredients."@en .
:Sweetener rdf:type owl:Class ; rdfs:subClassOf :Food ;
    rdfs:comment "Sugar and jaggery. Lifestyle tracking, excluded from WHO DDS scoring."@en .
:JunkFood rdf:type owl:Class ; rdfs:subClassOf :Food ;
    rdfs:comment "Lifestyle-tracking category, excluded from WHO DDS scoring."@en .
:Beverage rdf:type owl:Class ; rdfs:subClassOf :Food ;
    rdfs:comment "Tea, coffee and other drinks. Lifestyle-tracking category, excluded from WHO DDS scoring."@en .

:Nutrient rdf:type owl:Class .
:Macronutrient rdf:type owl:Class ; rdfs:subClassOf :Nutrient .
:Micronutrient rdf:type owl:Class ; rdfs:subClassOf :Nutrient .
:Symptom rdf:type owl:Class .
:Religion rdf:type owl:Class ;
    rdfs:comment "Used only to flag common food avoidances as a helpful default; not a claim about any individual's actual practice."@en .


#################################################################
#    Constraint axioms (v2.1)
#################################################################

[ rdf:type owl:AllDisjointClasses ;
  owl:members ( :Food :Nutrient :Symptom :Religion ) ] .

[ rdf:type owl:AllDisjointClasses ;
  owl:members ( :Grain :Legume :Vegetable :Fruit :Meat :Fish :Egg :Dairy :Oil :Sweetener :JunkFood :Beverage ) ] .

:GreenLeafy owl:disjointWith :OtherVegetable .
:CitrusFruit owl:disjointWith :OtherFruit .
:Macronutrient owl:disjointWith :Micronutrient .

:Food owl:hasKey ( :hasFCTCode ) .


#################################################################
#    Individuals — Nutrients (ICMR-NIN 2020 EAR + RDA)
#################################################################
''')

# build good-source / source links first (need food values)
foods_out = []
nutrient_sources = {k: [] for k in REF}
food_links = {}
for (ind, cls, code, fname, en, bn, serv, unit, orig) in F:
    rec = fct[code]
    vals, flags = {}, {}
    for col, prop, nut in COLS:
        v, fl = parse_val(rec.get(col))
        if v is None:
            if nut: flags.setdefault('unknown', []).append(nut)
            continue
        vals[prop] = v
        if fl == 'trace' and nut: flags.setdefault('trace', []).append(nut)
        if fl == 'lowq' and nut: flags.setdefault('lowq', []).append(nut)
    a4 = annex.get(code, {})
    if 'PHYTAC' in a4: vals['hasPhytate_mg_per_100g'] = float(a4['PHYTAC'].strip('[]'))
    if 'OXALAC' in a4: vals['hasOxalate_mg_per_100g'] = float(a4['OXALAC'].strip('[]'))
    has, good = [], []
    for col, prop, nut in COLS:
        if nut is None or prop not in vals: continue
        per_serv = vals[prop] * serv / 100.0
        if nut == 'Fat':
            if per_serv >= 5.0: has.append('Fat')
            continue
        pct = 100.0 * per_serv / REF[nut][4]
        if pct >= GOOD_PCT: good.append(nut); nutrient_sources[nut].append(ind)
        elif pct >= SOURCE_PCT: has.append(nut)
    enh, inh = [], []
    vc = vals.get('hasVitaminC_mg_per_100g', 0) * serv / 100.0
    if vc >= VITC_ENHANCER_MG or cls in MEAT_FISH_FACTOR: enh.append('Iron')
    if ind in POLYPHENOL_IRON: inh.append('Iron')
    if ind in PHYTATE: inh += ['Iron', 'Zinc']
    food_links[ind] = (has, good, enh, inh)
    foods_out.append((ind, cls, code, fname, en, bn, serv, unit, orig, vals, flags, has, good, enh, inh))

for nut, (ncls, em, ef, rm, rf, unit, src) in REF.items():
    sy = SYMPTOMS.get(nut, [])
    parts = [f':{nut} rdf:type owl:NamedIndividual , :{ncls}',
             f'    :hasEAR_male_daily {lit(em)}', f'    :hasEAR_female_daily {lit(ef)}',
             f'    :hasRDA_male_daily {lit(rm)}', f'    :hasRDA_female_daily {lit(rf)}',
             f'    :hasRequirementUnit {slit(unit)}', f'    :hasReferenceSource {slit(src)}']
    if sy: parts.append('    :causesSymptom ' + ' , '.join(':' + s for s in sy))
    w(' ;\n'.join(parts) + ' .\n')
w(''':Fat rdf:type owl:NamedIndividual , :Macronutrient ;
    rdfs:comment "No single EAR/RDA: total fat is set as a share of energy, not a fixed gram target."@en .
''')

w('''
#################################################################
#    Individuals — Symptoms
#################################################################
''')
for s in ['Fatigue','HairLoss','GumBleeding','NightBlindness','DryFlakySkin','BoneJointPain','FrequentIllness','PoorConcentration','PaleConjunctiva','Koilonychia']:
    w(f':{s} rdf:type owl:NamedIndividual , :Symptom .')
w('''
#################################################################
#    Individuals — Religions
#################################################################
''')
for r in ['Hinduism','Islam','Buddhism','Christianity']:
    w(f':{r} rdf:type owl:NamedIndividual , :Religion .')

w('''

#################################################################
#    Individuals — Foods
#    Values per 100 g edible portion, INFS Food Composition Table for Bangladesh (2013)
#################################################################
''')
order = ['Grain','MixedDish','Legume','GreenLeafy','OtherVegetable','CitrusFruit','OtherFruit','Meat','Fish','Egg','Dairy','Oil','JunkFood','Beverage','Sweetener']
prop_order = [p for _, p, _ in COLS] + ['hasPhytate_mg_per_100g','hasOxalate_mg_per_100g']
for grp in order:
    w(f'###  {grp}')
    for (ind, cls, code, fname, en, bn, serv, unit, orig, vals, flags, has, good, enh, inh) in [f for f in foods_out if f[1]==grp]:
        if '*' in fname and 'boiled' in fname: basis = 'boiled without salt (FCT recipe calculation)'
        elif '*' in fname: basis = 'recipe dish as eaten (FCT recipe calculation)'
        elif 'raw' in fname: basis = 'raw edible portion'
        else: basis = 'as purchased / ready to consume'
        p = [f':{ind} rdf:type owl:NamedIndividual , :{cls}',
             f'    rdfs:label {slit(en)}@en , {slit(bn)}@bn',
             f'    :hasFCTCode {slit(code)}', f'    :hasFCTName {slit(fname)}',
             f'    :isRecipeCalculated "{str("*" in fname).lower()}"^^xsd:boolean',
             f'    :valueBasis {slit(basis)}']
        for prop in prop_order:
            if prop in vals: p.append(f'    :{prop} {lit(vals[prop])}')
        p.append(f'    :hasServingSize_g {lit(float(serv))}')
        p.append('    :servingSizeSource ' + slit('v1 ontology (ICCIT submission)' if orig else 'v2 household-portion estimate; verify with weighed-plate data'))
        if unit: p.append(f'    :hasNaturalUnitLabel {slit(unit)}^^xsd:string')
        if good: p.append('    :isGoodSourceOf ' + ' , '.join(':'+n for n in good))
        if has: p.append('    :hasNutrient ' + ' , '.join(':'+n for n in has))
        if enh: p.append('    :enhancesAbsorption ' + ' , '.join(':'+n for n in enh))
        if inh: p.append('    :inhibitsAbsorption ' + ' , '.join(':'+n for n in dict.fromkeys(inh)))
        if flags.get('unknown'): p.append('    :hasUnknownValueFor ' + ' , '.join(':'+n for n in flags['unknown']))
        if flags.get('trace'): p.append('    :hasTraceValueFor ' + ' , '.join(':'+n for n in flags['trace']))
        if flags.get('lowq'): p.append('    :hasLowQualityValueFor ' + ' , '.join(':'+n for n in flags['lowq']))
        if ind in RELIGION: p.append(f'    :restrictedByReligion :{RELIGION[ind]}')
        notes = []
        if cls in ('Meat','Fish') and '*' not in fname:
            notes.append('Values are for RAW edible portion; cooked curry weight differs (water/oil change), so convert cooked grams before use.')
        if ind in PHYTATE:
            pc = PHYTATE[ind]; ph = annex.get(pc, {}).get('PHYTAC')
            notes.append(f'inhibitsAbsorption based on phytate of raw ingredient FCT {pc} ({ph} mg/100 g, FCT Annex 4).')
        if ind in POLYPHENOL_IRON:
            notes.append('Tea/coffee polyphenols reduce non-haem iron absorption when taken with meals (FCT Annex 3: tea powder total phenols 881 mg GAE/100 g).')
        if ind in ('Cha','DudhCha','Coffee'):
            notes.append('FCT recipe includes sugar' + (' and whole milk powder.' if ind != 'Cha' else '.'))
        if ind == 'Doi': notes.append('FCT has only sweetened curd (mishti doi); plain/sour doi will differ.')
        if ind == 'MasoorDal': notes.append('FCT boiled lentils without salt/oil; home dal is often more watery, so per-100 g values of a thin dal will be lower.')
        if ind == 'Amloki': notes.append('Botanically not citrus; kept in OtherFruit.')
        if ind in ('MurgirKoliza','GorurKoliza'): notes.append('Organ meat: very high vitamin A — recommend in moderation (weekly, small portions), not daily.')
        if notes: p.append('    rdfs:comment ' + slit(' '.join(notes)) + '@en')
        w(' ;\n'.join(p) + ' .\n')

w('###  Kept from v1 — NOT in INFS FCT 2013')
for ind, cls, en, bn, serv, vals in NOT_IN_FCT:
    p = [f':{ind} rdf:type owl:NamedIndividual , :{cls}', f'    rdfs:label {slit(en)}@en , {slit(bn)}@bn',
         '    :notInFCT "true"^^xsd:boolean', '    :valueBasis "as purchased"']
    for k, v in vals.items(): p.append(f'    :{k} {lit(v)}')
    p.append(f'    :hasServingSize_g {lit(float(serv))}')
    p.append('    :servingSizeSource "v1 ontology (ICCIT submission)"')
    p.append('    :hasNutrient :Fat , :Carbohydrate')
    p.append('    :hasUnknownValueFor :Calcium , :Iron , :Zinc , :VitaminA , :VitaminC , :VitaminD , :Folate')
    p.append('    rdfs:comment "Not in INFS FCT 2013. v1 values (USDA-style estimate) retained so the food stays in the graph; replace with a cited source before publication."@en')
    w(' ;\n'.join(p) + ' .\n')

all_inds = list(REF) + ['Fat'] + ['Fatigue','HairLoss','GumBleeding','NightBlindness','DryFlakySkin','BoneJointPain','FrequentIllness','PoorConcentration','PaleConjunctiva','Koilonychia'] + ['Hinduism','Islam','Buddhism','Christianity'] + [f[0] for f in F] + [n[0] for n in NOT_IN_FCT]
assert len(all_inds) == len(set(all_inds))
w('''
#################################################################
#    Unique names (v2.1): every named individual is a distinct entity
#################################################################

[ rdf:type owl:AllDifferent ;
  owl:distinctMembers (''')
for i in range(0, len(all_inds), 6):
    w('    ' + ' '.join(':' + x for x in all_inds[i:i+6]))
w('  ) ] .')
open(OUT, 'w').write('\n'.join(lines) + '\n')
print('foods:', len(foods_out) + len(NOT_IN_FCT))
for n, s in nutrient_sources.items(): print(n, len(s), s[:8])
