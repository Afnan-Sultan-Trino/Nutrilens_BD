import pdfplumber, re, sys, json, csv
CODE = re.compile(r'^\d\d_\d{4}$')
NUM = re.compile(r'^\(?\[?(tr|Tr|TR|\d+(?:\.\d+)?)\]?\)?$')
pdf = pdfplumber.open(sys.argv[1])
data = {}   # code -> dict
names = {}
issues = []

def blocks_of(ws):
    heads = sorted([w for w in ws if w['text']=='Code' and w['x0']<120], key=lambda w:w['top'])
    out=[]
    for i,h in enumerate(heads):
        lo = h['top'] - 32
        hi = heads[i+1]['top'] - 32 if i+1 < len(heads) else 1e9
        out.append([w for w in ws if lo <= w['top'] < hi])
    return out

for pn, p in enumerate(pdf.pages):
    allws = p.extract_words()
    for ws in blocks_of(allws):
        texts = [w['text'] for w in ws]
        codes = [w for w in ws if CODE.match(w['text']) and w['x0'] < 120]
        if not codes: continue
        first_top = min(c['top'] for c in codes)
        hdr = [w for w in ws if w['top'] < first_top - 2]
        htexts = [w['text'] for w in hdr]
        try:
            if 'Retinol' in htexts:
                kind = 'vit'
                units = sorted([w for w in hdr if w['text'] in ('(mcg)','(mg)')], key=lambda w: w['x0'])
                cols = ['VITA_RAE','RETOL','CARTBEQ','VITD','VITE','THIA','RIBF','NIA','VITB6A','FOL','ASCL']
                anchors = [((u['x0']+u['x1'])/2) for u in units]
            elif 'Ca' in htexts and 'Zn' in htexts:
                kind = 'min'
                anchors=[]
                for n in ['Ca','Fe','Mg','P','K','Na','Zn','Cu']:
                    a = [w for w in hdr if w['text']==n][0]
                    u = min([w for w in hdr if w['text']=='(mg)' and w['x0']>a['x0']], key=lambda w:w['x0'])
                    anchors.append((a['x0']+u['x1'])/2)
                cols = ['CA','FE','MG','P','K','NA','ZN','CU']
            elif 'Energy' in htexts:
                kind = 'prox'
                coef = [w for w in hdr if w['text'] in ('coefficient',)] or [w for w in hdr if w['text']=='portion']
                kcal = [w for w in hdr if w['text']=='(kcal)']
                kj = [w for w in hdr if w['text']=='kJ']
                g = sorted([w for w in hdr if w['text']=='(g)'], key=lambda w:w['x0'])
                anchors = [ (coef[0]['x0']+coef[0]['x1'])/2, (kcal[0]['x0']+kcal[0]['x1'])/2, (kj[0]['x0']+kj[0]['x1'])/2 ] + [ (w['x0']+w['x1'])/2 for w in g]
                cols = ['EDIBLE','ENERC_KCAL','ENERC_KJ','WATER','PROT','FAT','CHOAVLDF','FIB','ASH']
            else:
                continue
        except Exception as e:
            issues.append(f'page {pn+1}: header error {e}'); continue
        if len(anchors) != len(cols):
            issues.append(f'page {pn+1} {kind}: anchors {len(anchors)} != {len(cols)}'); continue
        xmin = min(anchors) - 25
        for c in codes:
            row = [w for w in ws if abs(w['top']-c['top'])<3.5 and w['x0']>xmin and w is not c]
            rec = data.setdefault(c['text'], {})
            rec.setdefault('_pages', []).append(pn+1)
            if kind == 'min':
                nm = [w for w in ws if abs(w['top']-c['top'])<13 and c['x1']<w['x0']<xmin and not CODE.match(w['text'])]
                nm.sort(key=lambda w:(round(w['top']),w['x0']))
                names[c['text']] = ' '.join(w['text'] for w in nm)
            for w in row:
                if not NUM.match(w['text']): continue
                cx = (w['x0']+w['x1'])/2
                j = min(range(len(anchors)), key=lambda k: abs(anchors[k]-cx))
                if abs(anchors[j]-cx) > 30:
                    issues.append(f'{c["text"]} p{pn+1} {kind}: far token {w["text"]} dx={anchors[j]-cx:.0f}')
                col = cols[j]
                if col in rec:
                    issues.append(f'{c["text"]} p{pn+1}: dup {col} {rec[col]} / {w["text"]}')
                rec[col] = w['text']
json.dump({'data':data,'names':names}, open('fct_parsed.json','w'), ensure_ascii=False, indent=0)
print(len(data), 'codes'); print('\n'.join(issues[:60])); print(len(issues),'issues')
