# Minimal Turtle parser (subset used by the ontology) + consistency checks.
import re, sys
src = open(sys.argv[1], encoding='utf-8').read()

TOK = re.compile(r'''
 (?P<ws>\s+|\#[^\n]*)
|(?P<tlit>"""(?:.|\n)*?""")
|(?P<lit>"(?:[^"\\\n]|\\.)*")
|(?P<iri><[^>\s]*>)
|(?P<dt>\^\^)
|(?P<lang>@[a-zA-Z]+(?:-[a-zA-Z0-9]+)*)
|(?P<pname>[A-Za-z_][\w\-]*:[\w\-]*|:[\w\-]+|:)
|(?P<kw>a\b|@prefix|@base)
|(?P<punct>[;,.()\[\]])
''', re.X)
toks = []; i = 0
while i < len(src):
    m = TOK.match(src, i)
    if not m: sys.exit(f'LEX ERROR at char {i}: {src[i:i+60]!r}')
    i = m.end()
    if m.lastgroup != 'ws': toks.append((m.lastgroup, m.group()))

prefixes = {}; triples = []; pos = 0
def peek(): return toks[pos] if pos < len(toks) else (None, None)
def nxt():
    global pos; t = toks[pos]; pos += 1; return t
def expect(v):
    t = nxt()
    if t[1] != v: sys.exit(f'PARSE ERROR: expected {v!r}, got {t} near token {pos}: {toks[pos-5:pos+3]}')
def term():
    k, v = nxt()
    if k in ('iri',): return ('iri', v)
    if k == 'pname':
        p = v.split(':')[0]
        if p not in prefixes: sys.exit(f'UNDECLARED PREFIX {p!r} in {v}')
        return ('pn', v)
    if k in ('lit', 'tlit'):
        if peek()[0] == 'dt': nxt(); return ('lit', v, nxt()[1])
        if peek()[0] == 'lang': return ('lit', v, nxt()[1])
        return ('lit', v, None)
    if v == '(':
        items = []
        while peek()[1] != ')': items.append(term())
        nxt(); return ('list', items)
    if v == 'a': return ('pn', 'rdf:type')
    sys.exit(f'PARSE ERROR: unexpected {k} {v!r} near {toks[pos-5:pos+3]}')
while pos < len(toks):
    k, v = peek()
    if v == '@prefix':
        nxt(); p = nxt()[1]; iri = nxt()[1]; expect('.'); prefixes[p.rstrip(':')] = iri; continue
    if v == '@base':
        nxt(); nxt(); expect('.'); continue
    s = term()
    while True:
        p = term()
        while True:
            o = term(); triples.append((s, p, o))
            if peek()[1] == ',': nxt(); continue
            break
        if peek()[1] == ';':
            nxt()
            if peek()[1] == '.': break
            continue
        break
    expect('.')

print(f'PARSE OK: {len(triples)} triples, prefixes={sorted(prefixes)}')

# ---- consistency checks
from collections import defaultdict
typ = defaultdict(set); props = defaultdict(lambda: defaultdict(list))
for s, p, o in triples:
    if s[0] == 'pn':
        props[s[1]][p[1]].append(o)
        if p[1] == 'rdf:type' and o[0] == 'pn': typ[s[1]].add(o[1])
classes = {s for s, t in typ.items() if 'owl:Class' in t}
objp = {s for s, t in typ.items() if 'owl:ObjectProperty' in t}
datap = {s for s, t in typ.items() if 'owl:DatatypeProperty' in t}
inds = {s for s, t in typ.items() if 'owl:NamedIndividual' in t}
errors = []
builtin = {'rdf:type', 'rdfs:label', 'rdfs:comment', 'rdfs:subClassOf', 'rdfs:domain', 'rdfs:range', 'owl:inverseOf',
           'owl:equivalentProperty', 'owl:deprecated', 'owl:propertyChainAxiom', 'rdfs:subPropertyOf', 'owl:versionInfo'}
ranges = {s: props[s]['rdfs:range'][0][1] for s in datap if props[s]['rdfs:range']}
for s, p, o in triples:
    pn = p[1]
    if pn not in builtin and pn not in objp and pn not in datap: errors.append(f'undeclared property {pn} on {s[1]}')
    if pn in objp and o[0] == 'pn' and o[1] not in inds: errors.append(f'{s[1]} {pn} -> undeclared individual {o[1]}')
    if pn in datap and o[0] == 'lit':
        if o[2] != ranges.get(pn) and not (o[2] is None and ranges.get(pn) == 'xsd:string'):
            errors.append(f'{s[1]} {pn}: datatype {o[2]} != range {ranges.get(pn)}')
    if pn == 'rdf:type' and o[0] == 'pn' and o[1] not in classes and not o[1].startswith('owl:'):
        errors.append(f'{s[1]} typed with undeclared class {o[1]}')
foodcls = {c for c in classes if c != ':Food'} - {':Nutrient', ':Macronutrient', ':Micronutrient', ':Symptom', ':Religion', ':Vegetable', ':Fruit'}
foods = [i for i in inds if typ[i] & foodcls]
for f in foods:
    d = props[f]
    if not d.get(':hasFCTCode') and not d.get(':notInFCT'): errors.append(f'{f}: no FCT code')
    langs = {o[2] for o in d.get('rdfs:label', [])}
    if langs != {'@en', '@bn'}: errors.append(f'{f}: labels {langs}')
    if not d.get(':hasServingSize_g'): errors.append(f'{f}: no serving size')
codes = defaultdict(list)
for f in foods:
    for o in props[f].get(':hasFCTCode', []): codes[o[1]].append(f)
for c, fs in codes.items():
    if len(fs) > 1: errors.append(f'duplicate FCT code {c}: {fs}')
print(f'foods={len(foods)} classes={len(classes)} objectProps={len(objp)} dataProps={len(datap)} individuals={len(inds)}')
print('ERRORS:' if errors else 'NO CONSISTENCY ERRORS', *errors[:40], sep='\n  ')
