import pdfplumber, re, sys, json
CODE = re.compile(r'^\d\d_\d{4}$')
NUM = re.compile(r'^\[?\d+(?:\.\d+)?\]?$')
pdf = pdfplumber.open(sys.argv[1]); out={}
for p in pdf.pages:
    ws = p.extract_words()
    t = [w['text'] for w in ws]
    if 'PHYTAC' not in t: continue
    ph = [w for w in ws if w['text']=='PHYTAC']; ox=[w for w in ws if w['text']=='OXALAC']; wa=[w for w in ws if w['text']=='Water']
    # may be several header blocks; use first (same columns per page)
    a = {'WATER':(wa[0]['x0']+wa[0]['x1'])/2,'PHYTAC':(ph[0]['x0']+ph[0]['x1'])/2,'OXALAC':(ox[0]['x0']+ox[0]['x1'])/2}
    for c in [w for w in ws if CODE.match(w['text'])]:
        row=[w for w in ws if abs(w['top']-c['top'])<3 and NUM.match(w['text'])]
        rec={}
        for w in row:
            cx=(w['x0']+w['x1'])/2
            k=min(a,key=lambda k:abs(a[k]-cx)); rec[k]=w['text']
        out[c['text']]=rec
json.dump(out,open('annex4.json','w'),indent=0)
for k in ['01_0001','01_0010','02_0008','04_0004','08_0012','14_0009','08_0035','05_0005']: print(k,out.get(k))
print(len(out))
